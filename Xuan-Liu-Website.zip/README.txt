Xuan Liu — Personal Website

Static website files, fonts, and images.
To preview: run python3 -m http.server 8000 in this folder, then open http://localhost:8000.
To deploy: upload all files and the assets folder to any static website host.
